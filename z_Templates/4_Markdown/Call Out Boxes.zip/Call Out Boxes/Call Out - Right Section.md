> [!infobox]+
> # Name
> ![[z_Assets/Misc/ImagePlaceholder.png|cover hsmall]]
> ###### Stats
> Type |  Stat |
> ---|---|
> Test | Testing |
> Test | Testing |
> Test | Testing |
> Test | Testing |