> [!danger]+ Trap
> Text