> [!example]+ Magic Item
> Text