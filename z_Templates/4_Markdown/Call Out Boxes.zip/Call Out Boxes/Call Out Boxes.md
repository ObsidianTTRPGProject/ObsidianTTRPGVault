---
---
# Call Out Boxes

> [!note]- Custom Name
> This is my text

> [!note]-
> This is my text 

> [!abstract]+
> Hi this is my note

> [!info]-
> This is my text

> [!tip]-
> This is my text

> [!success]-
> This is my text

> [!question]-
> This is my text

> [!warning]-
> This is my text

> [!failure]-
> This is my text

> [!danger]-
> This is my text

> [!bug]-
> This is my text

> [!example]-
> This is my text

> [!quote]-
> This is my text