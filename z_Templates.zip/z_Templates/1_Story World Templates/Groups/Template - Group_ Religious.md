---
ImportedOn: Saturday, 18 December 2021 8:41:47 PM
Tags: Category/Group--Religious
Type: Religious
Alignment: Chaotic Evil
Religious-Organization: House of Worship
parent:
  - Group_ Religious
up:
  - Group_ Religious
prev:
  - Template - Group_ Other
next:
  - Template - Adventure Area
RWtopicId: Topic_19
---
# Template - Group: Religious
## Overview
**Type**: Religious

**Alignment**: Chaotic Evil, Chaotic Good, Chaotic Neutral, Lawful Evil, Lawful Good, Lawful Neutral, Neutral, Neutral Evil, Neutral Good, Unaligned

**Religious Organization**: House of Worship, Chapter, Congregation, Cult, Denomination, Movement, Order, Other, Religion, Sect

### Placeholder Iconography
![[z_Assets/Misc/ImagePlaceholder.png|Placeholder Iconography]]
[[z_Assets/Misc/ImagePlaceholder.png|open outside]]

Placeholder

## Profile
Placeholder

## Story
Placeholder

## Faith and Beliefs
Placeholder

## Relationships
Placeholder

## Organization
**Headquarters**: Placeholder

**Leader(s)**: Placeholder

**Prominent Members**: Placeholder

Placeholder

## Resources
Placeholder

## Methods
Placeholder

## Background
Placeholder

## Additional Details
Placeholder

