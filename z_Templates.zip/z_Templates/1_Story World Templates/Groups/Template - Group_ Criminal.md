---
ImportedOn: Saturday, 18 December 2021 8:41:47 PM
Tags: Category/Group--Criminal
Type: Criminal
Alignment: Chaotic Evil
Criminal-Activities: Vice
Criminal-Organization: Cartel
parent:
  - Group_ Criminal
up:
  - Group_ Criminal
prev:
  - Template - Group_ Commerce
next:
  - Template - Group_ Ethnic
RWtopicId: Topic_13
---
# Template - Group: Criminal
## Overview
**Type**: Criminal

**Alignment**: Chaotic Evil, Chaotic Good, Chaotic Neutral, Lawful Evil, Lawful Good, Lawful Neutral, Neutral, Neutral Evil, Neutral Good, Unaligned

**Criminal Activities**: Vice, Arms Trafficking, Cybercrime, Drug Trafficking, Extortion, Financial Crime, Other, Person Trafficking, Political Corruption, Smuggling, Violence

**Criminal Organization**: Cartel, Gang, Guild, Mafia, Other, Ring, Syndicate

### Placeholder Iconography
![[z_Assets/Misc/ImagePlaceholder.png|Placeholder Iconography]]
[[z_Assets/Misc/ImagePlaceholder.png|open outside]]

Placeholder

## Profile
Placeholder

## Story
Placeholder

## Philosophy
Placeholder

## Relationships
Placeholder

## Organization
**Headquarters**: Placeholder

**Leader(s)**: Placeholder

**Prominent Members**: Placeholder

Placeholder

## Resources
Placeholder

## Methods
Placeholder

## Background
Placeholder

## Additional Details
Placeholder

