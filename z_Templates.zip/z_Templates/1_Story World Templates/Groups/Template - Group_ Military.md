---
ImportedOn: Saturday, 18 December 2021 8:41:47 PM
Tags: Category/Group--Military
Type: Military
Alignment: Chaotic Evil
Military-Role: Air
Military-Organization: Air Force
parent:
  - Group_ Military
up:
  - Group_ Military
prev:
  - Template - Group_ Government
next:
  - Template - Group_ Other
RWtopicId: Topic_17
---
# Template - Group: Military
## Overview
**Type**: Military

**Alignment**: Chaotic Evil, Chaotic Good, Chaotic Neutral, Lawful Evil, Lawful Good, Lawful Neutral, Neutral, Neutral Evil, Neutral Good, Unaligned ;

**Military Role**: Air, Armor, Artillery, Cavalry, Infantry, Logistics, Naval, Other, Reconaissance, Space, Strategic, Support

**Military Organization**: Air Force, Armada, Army, Battalion, Battlegroup, Brigade, Cohort, Company, Corps, Detachment, Division, Fleet, Flotilla, Formation, Legion, Navy, Other, Outfit, Platoon, Regiment, Section, Squad, Squadron, Task Force, Unit, Wing ;

### Placeholder Iconography
![[z_Assets/Misc/ImagePlaceholder.png|Placeholder Iconography]]
[[z_Assets/Misc/ImagePlaceholder.png|open outside]]

Placeholder

## Profile
Placeholder

## Story
Placeholder

## Philosophy
Placeholder

## Relationships
Placeholder

## Organization
**Headquarters**: Placeholder

**Leader(s)**: Placeholder

**Prominent Members**: Placeholder

Placeholder

## Forces and Resources
Placeholder

## Methods
Placeholder

## Background
Placeholder

## Additional Details
Placeholder

