---
ImportedOn: Saturday, 18 December 2021 8:41:47 PM
Tags: Category/Group--Other
Type: Other
Alignment: Chaotic Evil
parent:
  - Group_ Other
up:
  - Group_ Other
prev:
  - Template - Group_ Military
next:
  - Template - Group_ Religious
RWtopicId: Topic_18
---
# Template - Group: Other
## Overview
**Type**: Other

**Alignment**: Chaotic Evil, Chaotic Good, Chaotic Neutral, Lawful Evil, Lawful Good, Lawful Neutral, Neutral, Neutral Evil, Neutral Good, Unaligned

### Placeholder Iconography
![[z_Assets/Misc/ImagePlaceholder.png|Placeholder Iconography]]
[[z_Assets/Misc/ImagePlaceholder.png|open outside]]

Placeholder

## Profile
Placeholder

## Story
Placeholder

## Philosophy
Placeholder

## Relationships
Placeholder

## Organization
**Headquarters**: Placeholder

**Leader(s)**: Placeholder

**Prominent Members**: Placeholder

Placeholder

## Resources
Placeholder

## Methods
Placeholder

## Background
Placeholder

## Additional Details
Placeholder

