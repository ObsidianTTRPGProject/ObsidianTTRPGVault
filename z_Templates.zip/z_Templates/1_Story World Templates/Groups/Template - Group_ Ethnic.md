---
ImportedOn: Saturday, 18 December 2021 8:41:47 PM
Tags: Category/Group--Ethnic
Type: Ethnic
Ethnic-Identity: Homeland
parent:
  - Group_ Ethnic
up:
  - Group_ Ethnic
prev:
  - Template - Group_ Criminal
next:
  - Template - Group_ Family
RWtopicId: Topic_14
---
# Template - Group: Ethnic
## Overview
**Type**: Ethnic

**Ethnic Identity**: Homeland, Traditions, Language, Culture, Beliefs, Other

### Placeholder Iconography
![[z_Assets/Misc/ImagePlaceholder.png|Placeholder Iconography]]
[[z_Assets/Misc/ImagePlaceholder.png|open outside]]

Placeholder

## Profile
Placeholder

## Story
Placeholder

## Philosophy
Placeholder

## Relationships
Placeholder

## Organization
Placeholder

## Resources
Placeholder

## Methods
Placeholder

## Background
Placeholder

## Additional Details
Placeholder

