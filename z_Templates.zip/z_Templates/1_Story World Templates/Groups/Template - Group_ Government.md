---
ImportedOn: Saturday, 18 December 2021 8:41:47 PM
Tags: Category/Group--Government
Type: Government
Alignment: Chaotic Evil
Government-Role: Exploration
Government-Organization: Administration
parent:
  - Group_ Government
up:
  - Group_ Government
prev:
  - Template - Group_ Family
next:
  - Template - Group_ Military
RWtopicId: Topic_16
---
# Template - Group: Government
## Overview
**Type**: Government

**Alignment**: Chaotic Evil, Chaotic Good, Chaotic Neutral, Lawful Evil, Lawful Good, Lawful Neutral, Neutral, Neutral Evil, Neutral Good, Unaligned

**Government Role**: Exploration, Diplomatic, Economic, Leadership, Intelligence, Justice, Law Enforcement, Legislation, Military, Other, Propaganda

**Government Organization**: Administration, Agency, Branch, Bureau, Cabinet, Congress, Council, Court, Department, House, Other, Parliament

### Placeholder Iconography
![[z_Assets/Misc/ImagePlaceholder.png|Placeholder Iconography]]
[[z_Assets/Misc/ImagePlaceholder.png|open outside]]

Placeholder

## Profile
Placeholder

## Powers and Duties
Placeholder

## Story
Placeholder

## Philosophy
Placeholder

## Relationships
Placeholder

## Organization
**Headquarters**: Placeholder

**Leader(s)**: Placeholder

**Prominent Members**: Placeholder

Placeholder

## Resources
Placeholder

## Methods
Placeholder

## Background
Placeholder

## Additional Details
Placeholder

