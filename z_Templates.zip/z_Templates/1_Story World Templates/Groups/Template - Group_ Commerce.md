---
ImportedOn: Saturday, 18 December 2021 8:41:47 PM
Tags: Category/Group--Commerce
Type: Commerce
Alignment: Chaotic Evil
Commerce-Activities: Exploration
Commerce-Organization: Company
parent:
  - Group_ Commerce
up:
  - Group_ Commerce
prev:
  - Template - Group List
next:
  - Template - Group_ Criminal
RWtopicId: Topic_12
---
# Template - Group: Commerce
## Overview
**Type**: Commerce

**Alignment**: Chaotic Evil, Chaotic Good, Chaotic Neutral, Lawful Evil, Lawful Good, Lawful Neutral, Neutral, Neutral Evil, Neutral Good, Unaligned

**Commerce Activities**: Exploration, Transportation, Trade, Banking, Distribution, Investment, Manufacturing, Other, Raw Materials, Sales

**Commerce Organization**: Company, Conglomerate, Corporation, Guild, Other, Union

### Placeholder Iconography
![[z_Assets/Misc/ImagePlaceholder.png|Placeholder Iconography]]
[[z_Assets/Misc/ImagePlaceholder.png|open outside]]

Placeholder

## Profile
Placeholder

## Story
Placeholder

## Philosophy
Placeholder

## Relationships
Placeholder

## Organization
**Headquarters**: Placeholder

**Leader(s)**: Placeholder

**Prominent Members**: Placeholder

Placeholder

## Resources
Placeholder

## Methods
Placeholder

## Background
Placeholder

## Additional Details
Placeholder

