---
ImportedOn: Saturday, 18 December 2021 8:41:47 PM
Tags: Category/Group--Family
Type: Family
Family-Notability: Politics
parent:
  - Group_ Family
up:
  - Group_ Family
prev:
  - Template - Group_ Ethnic
next:
  - Template - Group_ Government
RWtopicId: Topic_15
---
# Template - Group: Family
## Overview
**Type**: Family

**Family Notability**: Politics, Industry, Commerce, Religion, Military, Crime, Other, Entertainment, Magic, Science, Technology

### Placeholder Iconography
![[z_Assets/Misc/ImagePlaceholder.png|Placeholder Iconography]]
[[z_Assets/Misc/ImagePlaceholder.png|open outside]]

Placeholder

## Profile
Placeholder

## Story
Placeholder

## Philosophy
Placeholder

## Relationships
Placeholder

## Organization
**Headquarters**: Placeholder

**Leader(s)**: Placeholder

**Prominent Members**: Placeholder

Placeholder

## Resources
Placeholder

## Methods
Placeholder

## Background
Placeholder

## Additional Details
Placeholder

