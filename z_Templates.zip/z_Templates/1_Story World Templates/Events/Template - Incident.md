---
ImportedOn: Saturday, 18 December 2021 8:41:47 PM
Tags: Category/Incident
parent:
  - Incident
up:
  - Incident
prev:
  - Template - Event List
next:
  - Template - Quest
RWtopicId: Topic_3
---
# Template - Incident
## Overview
**Date**: Monday, 1 January -20000 12:00:00 AM

Placeholder

## Description
Placeholder

## Location
Placeholder

## Causes and Effects
Placeholder

## Story
Placeholder

## Relationships
Placeholder

## Background
Placeholder

## Additional Details
Placeholder

