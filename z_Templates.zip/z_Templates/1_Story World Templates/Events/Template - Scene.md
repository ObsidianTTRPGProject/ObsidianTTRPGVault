---
ImportedOn: Saturday, 18 December 2021 8:41:47 PM
Tags: Category/Scene
Scene-Type: Conclusion
Setting: Extradimensional
Encounter-Type: Exploration
parent:
  - Scene
up:
  - Scene
prev:
  - Template - Quest
next:
  - Template - Storyline
RWtopicId: Topic_5
---
# Template - Scene
## Overview
**Scene Type**: Conclusion, Description, Encounter, Exposition, Introduction, Other, Preparation, Revelation, Transition

**Setting**: Extradimensional, Indoors, Interstellar, Nautical, Other, Outdoors, Underground, Urban, Wilderness

**Encounter Type**: Exploration, Combat, Social, Subterfuge, Skill Challenge, Puzzle, Roleplaying, Investigative

### Image
![[z_Assets/Misc/ImagePlaceholder.png|Image]]
[[z_Assets/Misc/ImagePlaceholder.png|open outside]]

Placeholder

## Setup
### Map
![[z_Assets/Misc/MapPlaceholder.png|Map]]
[[z_Assets/Misc/MapPlaceholder.png|open outside]]

Placeholder

## Participants
Placeholder - Encounter Code

Placeholder - Statblock Code

### Placeholder Portrait
![[z_Assets/Misc/ImagePlaceholder.png|Placeholder Portrait]]
[[z_Assets/Misc/ImagePlaceholder.png|open outside]]

Placeholder

## Challenge
Placeholder

## Obstacles
Placeholder

## Rewards
Placeholder

## Background
Placeholder

## Additional Details
Placeholder

