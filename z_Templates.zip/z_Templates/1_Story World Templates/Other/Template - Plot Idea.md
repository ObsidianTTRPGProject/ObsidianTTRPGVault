---
ImportedOn: Saturday, 18 December 2021 8:41:47 PM
Tags: Category/Plot-Idea
Genre: Alternative History
Tone: Action
Plot-Structure: Branching
Plot-Focus: Exploration
Genre-Easily-Adapted-To: Alternative History
Tone-Easily-Adapted-To: Action
parent:
  - Plot Idea
up:
  - Plot Idea
prev:
  - Template - Plot Hook
next:
  - Template - Story Gallery
RWtopicId: Topic_40
---
# Template - Plot Idea
## Overview
**Genre**: Alternative History

**Tone**: Action

**Plot Structure**: Branching

**Plot Focus**: Exploration, Advancement, Roleplaying, Narrative, Combat, Other, Intrigue, Investigative, Social, Subterfuge

Placeholder

## Synopsis
Placeholder

## Key People, Places, and Things
Placeholder

## Scene Outline
Placeholder

## Setup
Placeholder

## Details
Placeholder

## Resolution
Placeholder

## Campaign Integration
Placeholder

## Additional Details
**Genre Easily Adapted To**: Alternative History

**Tone Easily Adapted To**: Action

Placeholder

