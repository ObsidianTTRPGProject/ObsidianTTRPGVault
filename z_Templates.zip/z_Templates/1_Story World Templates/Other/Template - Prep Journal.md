---
---
## Characters 
 
**Name.** Description. 
 
**Name.** Description. 
 
**Name.** Description. 
 
**Name.** Description. 
 
## Strong Start 
 
Description of your strong start. 
 
## Scenes 
 
* Small scene description. 
* 
* 
* 
* 
 
## Secrets and Clues 
 
* Secret description 
* 
* 
* 
* 
* 
* 
* 
* 
* 
 
## Fantastic Locations 
 
**Location**: aspect, aspect, aspect 
 
**Location**: aspect, aspect, aspect 
 
**Location**: aspect, aspect, aspect 
 
**Location**: aspect, aspect, aspect 
 
## Important NPCs 
 
**Name.** Description 
 
**Name.** Description 
 
**Name.** Description 
 
**Name.** Description 
 
## Potential Monsters 
 
* Name 
* 
* 
* 
## Potential Treasure 
 
* Description 
* 
* 
*