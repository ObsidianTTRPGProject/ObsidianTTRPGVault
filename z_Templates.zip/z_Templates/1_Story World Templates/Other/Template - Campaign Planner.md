---
---
### Campaign Hook
What is this campaign about? What is the goal?

### Six Truths Of Your World
What makes this campaign unique?

### Campaign Fronts
What are the major moving forces in this campaign?

#### Front 1
**Goal:**
**Three Grim Portents:**

#### Front 2
**Goal:**
**Three Grim Portents:**

#### Front 3
**Goal:**
**Three Grim Portents:**