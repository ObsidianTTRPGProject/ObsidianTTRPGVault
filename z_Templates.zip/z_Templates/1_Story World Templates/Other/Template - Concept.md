---
ImportedOn: Saturday, 18 December 2021 8:41:47 PM
Tags: Category/Concept
parent:
  - Concept
up:
  - Concept
prev:
  - Template - Thing List
next:
  - Template - Further Information
RWtopicId: Topic_35
---
# Template - Concept
## Overview
Placeholder

## Description
Placeholder

## Story
Placeholder

## Origin
Placeholder

## Downfall
Placeholder

## Proponents
Placeholder

## Detractors
Placeholder

## Counterparts
Placeholder

## Opposition
Placeholder

## Background
Placeholder

## Additional Details
Placeholder

