---
ImportedOn: Saturday, 18 December 2021 8:41:47 PM
Tags: Category/Player-Synopsis
parent:
  - Player Synopsis
up:
  - Player Synopsis
prev:
  - Template - GM Synopsis
next:
  - Template - Story Source
RWtopicId: Topic_44
---
# Template - Player Synopsis
## Overview
Placeholder

## Important Places
Placeholder

## Important Characters
Placeholder

## Important Plot Elements
Placeholder

