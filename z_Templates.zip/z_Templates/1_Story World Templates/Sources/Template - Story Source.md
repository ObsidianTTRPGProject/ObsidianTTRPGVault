---
ImportedOn: Saturday, 18 December 2021 8:41:47 PM
Tags: Category/Story-Source
parent:
  - Story Source
up:
  - Story Source
prev:
  - Template - Player Synopsis
next:
  - Template - Mechanics Source
RWtopicId: Topic_45
---
# Template - Story Source
## Overview
Placeholder

