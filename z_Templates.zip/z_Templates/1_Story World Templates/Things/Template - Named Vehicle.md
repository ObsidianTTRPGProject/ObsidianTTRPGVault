---
ImportedOn: Saturday, 18 December 2021 8:41:47 PM
Tags: Category/Named-Vehicle
Transport-Medium: Land
parent:
  - Named Vehicle
up:
  - Named Vehicle
prev:
  - Template - Named Object
next:
  - Template - Object Collection
RWtopicId: Topic_32
---
# Template - Named Vehicle
## Overview
**Transport Medium**: Land, Water, Air, Space, Time, Dimensional, Other

### Placeholder Picture
![[z_Assets/Misc/ImagePlaceholder.png|Placeholder Picture]]
[[z_Assets/Misc/ImagePlaceholder.png|open outside]]

Placeholder

## Profile
Placeholder

## Story
Placeholder

## Relationships
Placeholder

## Transportation
Placeholder

## Operation
Placeholder

## Capabilities
Placeholder

## Background
Placeholder

## Additional Details
Placeholder

