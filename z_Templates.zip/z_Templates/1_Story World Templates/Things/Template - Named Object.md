---
ImportedOn: Saturday, 18 December 2021 8:41:47 PM
Tags: Category/Named-Object
parent:
  - Named Object
up:
  - Named Object
prev:
  - Template - Named Equipment
next:
  - Template - Named Vehicle
RWtopicId: Topic_31
---
# Template - Named Object
## Overview
### Placeholder Picture
![[z_Assets/Misc/ImagePlaceholder.png|Placeholder Picture]]
[[z_Assets/Misc/ImagePlaceholder.png|Placeholder]]

Placeholder

## Profile
Placeholder

## Story
Placeholder

## Relationships
Placeholder

## Capabilities
Placeholder

## Components
Placeholder

## Background
Placeholder

## Additional Details
Placeholder

