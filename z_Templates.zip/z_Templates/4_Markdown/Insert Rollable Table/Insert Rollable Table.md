---
---
`dice: [[Insert Rollable Table]]^TableName]]`

| `dice: 1d10` | Traveler                                                                     |
| --- | ---------------------------------------------------------------------------- |
| 1   | Solitary fighter (veteran)                                                   |
| 2   | Solitary cleric (priest)                                                     |
| 3   | Solitary wizard (mage)                                                       |
| 4   | Solitary thief (spy)                                                         |
| 5   | Adventuring party (1d4 NPC characters). Roll 1d4 on this table for each NPC. |
| 6   | Merchants                                                                    |
| 7   | 1d4 fighters (guards)                                                        |
| 8   | 1d6 outlaws                                                                  |
| 9   | Patrol                                                                       |
| 10  | 2d6 mercenaries                                                              |
^TableName
