---
---
`dice: [[Insert Rollable Table]]^TableName]]`

| d4  | -   |
| --- | --- |
| 1   |     |
| 2   |     |
| 3   |     |
| 4   |     |
^TableName
