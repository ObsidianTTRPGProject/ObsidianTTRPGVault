- [ ] Empty
- [x] Regular
- [?] Checked
- [-] Dropped
- [>] Forward
- [D] Defer
- [?] Question
- [/] Half
- [+] Add
- [R] Research
- [!] Important
- [i] Idea
- [B] Brainstorm
- [P] Pro
- [C] Con
- [Q] Quote
- [N] Note
- [B] Bookmark
- [I] Info
- [p] Parafrase
- [L] Location
- [E] Example
- [A] Answer
- [r] Reward
- [c] Choice 



