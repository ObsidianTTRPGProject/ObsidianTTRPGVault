```encounter
name: Weak Party
creatures:
 - 1: Thug
 - 2: Goblin, 5, 15, 2, 25      # 1 goblin with HP: 7, AC: 15, MOD: 2 worth 25 XP will be added.

---

name: Strong Party
creatures:
 - 1: Thug
 - 5: Bandit

---

name: Very Strong Party
creatures:
 - 2: Thug
 - 4: Bandit

```
