```statblock
monster: Goblin
```