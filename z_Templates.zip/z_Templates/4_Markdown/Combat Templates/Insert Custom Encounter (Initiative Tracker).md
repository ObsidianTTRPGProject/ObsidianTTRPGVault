```encounter
creatures:
  - My Monster          # 1 monster named My Monster will be added, with no HP, AC or modifier.
  - 1: Goblin, 7, 15, 2        # 1 goblin with HP: 7, AC: 15, MOD: 2 will be added.
  - 1d6: Goblin, 5, 15, 2, 25      # 1 goblin with HP: 7, AC: 15, MOD: 2 worth 25 XP will be added.
```
