| **`dice: D6`** | **Encounter**                                |
| -------------- | -------------------------------------------- |
| 1              | `encounter: 4: Kobold`                       |
| 2              | `encounter: 1d6: Kobold, 1d4: Winged Kobold` |
| 3              | Do something else                            |
| 4              |                                              | 
| 5              |                                              |
| 6              |                                              |
