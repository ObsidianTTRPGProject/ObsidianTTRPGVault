---
ImportedOn: Saturday, 18 December 2021 8:41:47 PM
Tags: Category/Mundane-Weapon
Type: Martial Melee Weapons
Era: Medieval Item
parent:
  - Mundane Weapon
up:
  - Mundane Weapon
prev:
  - Template - Mundane Item
next:
  - Template - Vehicle
RWtopicId: Topic_56
---
# Template - Mundane Weapon
## Overview
**Price**: Placeholder

### Placeholder Picture
![[z_Assets/Misc/ImagePlaceholder.png|Placeholder Picture]]
[[z_Assets/Misc/ImagePlaceholder.png|open outside]]

**Weight**: Placeholder

**Type**: Martial Melee Weapons

**Era**: Medieval Item

**Damage**: Placeholder

**Properties**: Placeholder

Placeholder

## Description
Placeholder

## Additional Details
Placeholder

