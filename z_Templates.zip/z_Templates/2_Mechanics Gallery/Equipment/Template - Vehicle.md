---
ImportedOn: Saturday, 18 December 2021 8:41:47 PM
Tags: Category/Vehicle
parent:
  - Vehicle
up:
  - Vehicle
prev:
  - Template - Mundane Weapon
next:
  - Template - Feat
RWtopicId: Topic_57
---
# Template - Vehicle
## Overview
### Placeholder Picture
![[z_Assets/Misc/ImagePlaceholder.png|Placeholder Picture]]
[[z_Assets/Misc/ImagePlaceholder.png|open outside]]

**AC**: Placeholder

**Price**: Placeholder

**Speed**: Placeholder

**Crew**: Placeholder

**Passengers**: Placeholder

**Cargo (tons)**: Placeholder

**HP**: Placeholder

**Damage Threshold**: Placeholder

Placeholder

## Description
Placeholder

## Additional Details
Placeholder

