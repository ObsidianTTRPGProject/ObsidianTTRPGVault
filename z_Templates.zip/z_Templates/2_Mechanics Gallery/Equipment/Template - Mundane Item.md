---
ImportedOn: Saturday, 18 December 2021 8:41:47 PM
Tags: Category/Mundane-Item
parent:
  - Mundane Item
up:
  - Mundane Item
prev:
  - Template - Mundane Armor_Shield
next:
  - Template - Mundane Weapon
RWtopicId: Topic_55
---
# Template - Mundane Item
## Overview
**Price**: Placeholder

**Weight**: Placeholder

### Placeholder Picture
![[z_Assets/Misc/ImagePlaceholder.png|Placeholder Picture]]
[[z_Assets/Misc/ImagePlaceholder.png|open outside]]

Placeholder

## Description
Placeholder

## Additional Details
Placeholder

