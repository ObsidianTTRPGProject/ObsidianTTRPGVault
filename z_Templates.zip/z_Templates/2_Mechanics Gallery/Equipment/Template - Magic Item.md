---
ImportedOn: Saturday, 18 December 2021 8:41:47 PM
Tags: Category/Magic-Item
Type: Magic Item
Group: Wondrous Items
Rarity: Common
parent:
  - Magic Item
up:
  - Magic Item
prev:
  - Template - General Equipment Article
next:
  - Template - Mundane Armor_Shield
RWtopicId: Topic_53
---
# Template - Magic Item
## Overview
**Type**: Magic Item

**Group**: Wondrous Items

**Rarity**: Common

**Attunement**: Placeholder

### Placeholder Picture
![[z_Assets/Misc/ImagePlaceholder.png|Placeholder Picture]]
[[z_Assets/Misc/ImagePlaceholder.png|open outside]]

Placeholder

## Description
Placeholder

## Construction
Placeholder

## Additional Details
Placeholder

