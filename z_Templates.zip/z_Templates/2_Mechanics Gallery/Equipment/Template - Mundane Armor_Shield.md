---
ImportedOn: Saturday, 18 December 2021 8:41:47 PM
Tags: Category/Mundane-Armor-Shield
Type: Light Armor
parent:
  - Mundane Armor_Shield
up:
  - Mundane Armor_Shield
prev:
  - Template - Magic Item
next:
  - Template - Mundane Item
RWtopicId: Topic_54
---
# Template - Mundane Armor/Shield
## Overview
**Price**: Placeholder

### Placeholder Picture
![[z_Assets/Misc/ImagePlaceholder.png|Placeholder Picture]]
[[z_Assets/Misc/ImagePlaceholder.png|open outside]]

**Weight**: Placeholder

**Type**: Light Armor

**Armor Class**: Placeholder

**Min. Strength**: Placeholder

**Stealth**: Placeholder

Placeholder

## Description
Placeholder

## Additional Details
Placeholder

