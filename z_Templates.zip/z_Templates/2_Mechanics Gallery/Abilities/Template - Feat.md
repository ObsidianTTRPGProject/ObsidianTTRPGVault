---
ImportedOn: Saturday, 18 December 2021 8:41:47 PM
Tags: Category/Feat
parent:
  - Feat
up:
  - Feat
prev:
  - Template - Vehicle
next:
  - Template - General Abilities Article
RWtopicId: Topic_58
---
# Template - Feat
## Overview
Placeholder

## Requirements and Restrictions
**Prerequisite**: Placeholder

Placeholder

## Effects
Placeholder

