---
ImportedOn: Saturday, 18 December 2021 8:41:47 PM
Tags: Category/Skill
parent:
  - Skill
up:
  - Skill
prev:
  - Template - General Abilities Article
next:
  - Template - Spell
RWtopicId: Topic_60
---
# Template - Skill
## Overview
Placeholder

## Requirements and Restrictions
Placeholder

## Effects
Placeholder

