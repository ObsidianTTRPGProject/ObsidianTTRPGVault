---
ImportedOn: Saturday, 18 December 2021 8:41:47 PM
Tags: Category/Trap
parent:
  - Trap
up:
  - Trap
prev:
  - Template - Poison
next:
  - Template - General Game Mastering Article
RWtopicId: Topic_69
---
# Template - Trap
## Overview
Placeholder

## Conditions
Placeholder

## Effects
Placeholder

## Avoidance and Mitigation
Placeholder

## Additional Details
Placeholder

