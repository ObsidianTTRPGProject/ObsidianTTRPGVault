---
ImportedOn: Saturday, 18 December 2021 8:41:47 PM
Tags: Category/Disease
parent:
  - Disease
up:
  - Disease
prev:
  - Template - Creature
next:
  - Template - General Dangers Article
RWtopicId: Topic_65
---
# Template - Disease
## Overview
Placeholder

## Becoming Afflicted
Placeholder

## Effects
Placeholder

## Prevention and Recovery
Placeholder

