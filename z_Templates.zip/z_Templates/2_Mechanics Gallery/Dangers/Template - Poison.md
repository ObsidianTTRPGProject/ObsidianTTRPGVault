---
ImportedOn: Saturday, 18 December 2021 8:41:47 PM
Tags: Category/Poison
Type: Injury
parent:
  - Poison
up:
  - Poison
prev:
  - Template - Hazard
next:
  - Template - Trap
RWtopicId: Topic_68
---
# Template - Poison
## Overview
**Type**: Injury

**Price**: Placeholder

Placeholder

## Becoming Afflicted
Placeholder

## Effects
Placeholder

## Prevention and Recovery
Placeholder

## Obtaining
Placeholder

