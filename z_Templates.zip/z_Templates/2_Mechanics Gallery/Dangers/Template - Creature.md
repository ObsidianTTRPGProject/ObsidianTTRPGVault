---
ImportedOn: Saturday, 18 December 2021 8:41:47 PM
Tags: Category/Creature
Alignment: Neutral
Challenge: CR 1
Size: Medium
Type: Humanoid
Creature-Tags: Aarakocra
parent:
  - Creature
up:
  - Creature
prev:
  - Template - General Gameplay Article
next:
  - Template - Disease
RWtopicId: Topic_64
---
# Template - Creature
## Overview
### Placeholder Portrait
![[z_Assets/Misc/ImagePlaceholder.png|Placeholder Portrait]]
[[z_Assets/Misc/ImagePlaceholder.png|open outside]]

**Alignment**: Neutral

**Armor Class**: Placeholder

**Hit Points**: Placeholder

**Speed**: Placeholder

**Challenge**: CR 1

**Experience**: Placeholder

Placeholder

## Other Details
**Ability Scores**: | STR | DEX | CON | WIS | INT | CHA |
|---|---|---|---|---|---|
| 0(+0) | 0(+0) | 0(+0) | 0(+0) | 0(+0) | 0(+0) |

**Saving Throws**: Placeholder

**Skills**: Placeholder

**Damage Vulnerabilities**: Placeholder

**Damage Resistances**: Placeholder

**Damage Immunities**: Placeholder

**Condition Immunities**: Placeholder

**Senses**: Placeholder

**Languages**: Placeholder

**Size**: Medium

**Type**: Humanoid

**Creature Tags**: Aarakocra

Placeholder

## Special Traits
Placeholder

## Actions
Placeholder

## Reactions
Placeholder

## Legendary Actions
Placeholder

## Description
Placeholder

## Additional Details
Placeholder

