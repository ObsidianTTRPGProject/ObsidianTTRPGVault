---
ImportedOn: Saturday, 18 December 2021 8:41:47 PM
Tags: Category/Hazard
Source: ABC
SourceType: Trap
TrapType: Mechanical/Magical Trap
parent:
  - Hazard
up:
  - Hazard
prev:
  - Template - General Dangers Article
next:
  - Template - Poison
RWtopicId: Topic_67
---
# Template - Hazard
## Overview
Placeholder

## Conditions
Placeholder

## Effects
Placeholder

## Avoidance and Mitigation
Placeholder

