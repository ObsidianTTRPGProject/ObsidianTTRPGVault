---
name: {{Name}}
aura: {{Aura}}
cl: {{CL}}
slot: {{Slot}}
price: {{Price}}
weight: {{Weight}}
group: {{Group}}
source: {{Source}}
baseitem: {{BaseItem}}
---

# {{Name}}
**Source:** {{Slot}}
**Aura:** {{Aura}}, **CL:** {{CL}}
**Slot:** {{Slot}}, **Price:** {{Price}}, **Weight:** {{Weight}}
**Group:** {{Group}}, **Base Item:** {{BaseItem}}
#### **Description**
{{Description}}

